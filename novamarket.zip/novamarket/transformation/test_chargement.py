"""Preuve : un échec en cours de lot ne laisse aucune écriture partielle.
Usage : python s4/transformation/test_chargement.py  (NOVAMARKET_DSN requis)"""
import os
import sys
import tempfile
from pathlib import Path

import psycopg

sys.path.insert(0, str(Path(__file__).parent))
import chargement_postgres as c

LIGNE = '{{"offer_id":"{}","supplier_id":"F01","product_id":{},"price_cents":5,"currency":"EUR","available_units":1,"observed_on":"2026-12-01"}}\n'
lot = Path(tempfile.mkdtemp()) / "lot.jsonl"
# N1 valide ; N2 passe la validation Python (catalogue forcé) mais viole la FK en base
lot.write_text(LIGNE.format("TEST_N1", 1) + LIGNE.format("TEST_N2", 9999))

with psycopg.connect(os.environ["NOVAMARKET_DSN"]) as db:
    c.initialiser(db)
    db.commit()
    try:
        c.charger(db, lot, catalogue={1, 9999})
        db.commit()
        raise SystemExit("ÉCHEC DU TEST : l'erreur FK attendue n'a pas eu lieu")
    except psycopg.errors.ForeignKeyViolation:
        db.rollback()
    n = db.execute("SELECT count(*) FROM fournisseur.offres WHERE offer_id LIKE 'TEST_%'").fetchone()[0]
    assert n == 0, f"écriture partielle : {n} ligne(s)"
    print("OK : FK violée sur la 2e ligne, la 1re a été annulée (0 ligne TEST_*)")
