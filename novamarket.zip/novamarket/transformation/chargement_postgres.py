"""Charge les offres fournisseurs valides (JSONL S3) dans PostgreSQL.

Grain d'une observation : (offer_id, observed_on) = une offre à une date donnée.
Une même offre peut donc avoir plusieurs dates sans collision ; rejouer un lot
ne crée aucun doublon (INSERT ... ON CONFLICT) et tout le lot tient dans une
seule transaction (tout ou rien).

Connexion : variable NOVAMARKET_DSN (+ PGPASSWORD ou PGPASSFILE), jamais en dur.
"""

import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path

import psycopg

RACINE = Path(__file__).resolve().parents[1]
ENTREE_DEFAUT = RACINE / "ingestion/data/valid/offres.jsonl"
ENTREE_SECOURS = Path(__file__).resolve().parent / "secours/offres.jsonl"
PRODUITS_CSV = RACINE / "s1/donnees/products.csv"
DEVISES = {"EUR"}

DDL = """
CREATE SCHEMA IF NOT EXISTS fournisseur;
CREATE TABLE IF NOT EXISTS public.products (
    product_id      integer PRIMARY KEY,
    sku             text NOT NULL,
    product_name    text NOT NULL,
    category_id     integer NOT NULL,
    first_listed_on date NOT NULL
);
CREATE TABLE IF NOT EXISTS fournisseur.offres (
    offer_id        text    NOT NULL CHECK (offer_id <> ''),
    observed_on     date    NOT NULL,
    supplier_id     text    NOT NULL CHECK (supplier_id ~ '^F[0-9]{2}$'),
    product_id      integer NOT NULL REFERENCES public.products (product_id),
    price_cents     integer NOT NULL CHECK (price_cents >= 0),
    currency        text    NOT NULL CHECK (currency = 'EUR'),
    available_units integer NOT NULL CHECK (available_units >= 0),
    loaded_at       timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (offer_id, observed_on)
);
"""

UPSERT = """
INSERT INTO fournisseur.offres
    (offer_id, observed_on, supplier_id, product_id, price_cents, currency, available_units)
VALUES (%(offer_id)s, %(observed_on)s, %(supplier_id)s, %(product_id)s,
        %(price_cents)s, %(currency)s, %(available_units)s)
ON CONFLICT (offer_id, observed_on) DO UPDATE SET
    supplier_id = excluded.supplier_id, product_id = excluded.product_id,
    price_cents = excluded.price_cents, currency = excluded.currency,
    available_units = excluded.available_units, loaded_at = now()
WHERE (offres.supplier_id, offres.product_id, offres.price_cents,
       offres.currency, offres.available_units)
      IS DISTINCT FROM (excluded.supplier_id, excluded.product_id,
       excluded.price_cents, excluded.currency, excluded.available_units)
RETURNING (xmax = 0) AS insere
"""


def _entier(v):
    return isinstance(v, int) and not isinstance(v, bool)


def valider(ligne: dict, catalogue: set[int]) -> tuple[dict | None, str | None]:
    """Retourne (offre typée, None) ou (None, motif de rejet)."""
    if not isinstance(ligne, dict):
        return None, "ligne non objet"
    attendus = (
        "offer_id",
        "supplier_id",
        "product_id",
        "price_cents",
        "currency",
        "available_units",
        "observed_on",
    )
    manquants = [c for c in attendus if ligne.get(c) in (None, "")]
    if manquants:
        return None, f"champs manquants : {','.join(manquants)}"
    for c in ("product_id", "price_cents", "available_units"):
        if not _entier(ligne[c]):
            return None, f"{c} non entier"
    if ligne["price_cents"] < 0 or ligne["available_units"] < 0:
        return None, "valeur négative"
    if ligne["currency"] not in DEVISES:
        return None, f"devise inconnue : {ligne['currency']}"
    if ligne["product_id"] not in catalogue:
        return None, f"produit inconnu : {ligne['product_id']}"
    try:
        jour = date.fromisoformat(ligne["observed_on"])
    except (TypeError, ValueError):
        return None, "observed_on invalide"
    if not (
        isinstance(ligne["offer_id"], str) and isinstance(ligne["supplier_id"], str)
    ):
        return None, "offer_id/supplier_id non texte"
    return {**{c: ligne[c] for c in attendus}, "observed_on": jour}, None


def lire_jsonl(chemin: Path):
    with open(chemin, encoding="utf-8") as f:
        for n, brut in enumerate(f, 1):
            if brut.strip():
                try:
                    yield n, json.loads(brut)
                except json.JSONDecodeError:
                    yield n, None


def initialiser(db: psycopg.Connection) -> None:
    """Crée schéma/tables et charge le référentiel produits (S1) s'il est vide."""
    db.execute(DDL)
    if db.execute("SELECT count(*) FROM public.products").fetchone()[0] == 0:
        import csv

        with open(PRODUITS_CSV, encoding="utf-8", newline="") as f, db.cursor() as cur:
            cur.executemany(
                "INSERT INTO public.products VALUES (%(product_id)s, %(sku)s, "
                "%(product_name)s, %(category_id)s, %(first_listed_on)s) "
                "ON CONFLICT (product_id) DO NOTHING",  # products.csv contient le produit 3 en double
                list(csv.DictReader(f)),
            )


def charger(
    db: psycopg.Connection, chemin: Path, catalogue: set[int] | None = None
) -> dict:
    """Charge un lot dans la transaction courante de `db` (commit à l'appelant)."""
    if catalogue is None:
        catalogue = {r[0] for r in db.execute("SELECT product_id FROM public.products")}
    bilan = {
        "lues": 0,
        "inserees": 0,
        "mises_a_jour": 0,
        "inchangees": 0,
        "rejetees": 0,
        "rejets": [],
    }
    vues = set()
    for n, ligne in lire_jsonl(chemin):
        bilan["lues"] += 1
        offre, motif = (
            (None, "JSON invalide") if ligne is None else valider(ligne, catalogue)
        )
        if offre and (offre["offer_id"], offre["observed_on"]) in vues:
            offre, motif = None, "doublon dans le lot"
        if offre is None:
            bilan["rejetees"] += 1
            bilan["rejets"].append({"ligne": n, "motif": motif})
            continue
        vues.add((offre["offer_id"], offre["observed_on"]))
        res = db.execute(UPSERT, offre).fetchone()
        if res is None:
            bilan["inchangees"] += 1
        elif res[0]:
            bilan["inserees"] += 1
        else:
            bilan["mises_a_jour"] += 1
    return bilan


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument(
        "--entree", type=Path, help="JSONL valide (défaut : S3, sinon secours)"
    )
    args = p.parse_args()
    if "NOVAMARKET_DSN" not in os.environ:
        print("NOVAMARKET_DSN non défini", file=sys.stderr)
        return 2
    entree = args.entree or (
        ENTREE_DEFAUT if ENTREE_DEFAUT.exists() else ENTREE_SECOURS
    )
    print(f"Entrée : {entree}")
    try:
        with psycopg.connect(os.environ["NOVAMARKET_DSN"], connect_timeout=5) as db:
            # `with` : commit si tout passe, rollback si exception -> pas d'écriture partielle
            initialiser(db)
            bilan = charger(db, entree)
    except psycopg.Error as e:
        print(f"ÉCHEC, rien n'a été écrit : {e}", file=sys.stderr)
        return 1
    for k in ("lues", "inserees", "mises_a_jour", "inchangees", "rejetees"):
        print(f"{k:>13} : {bilan[k]}")
    for r in bilan["rejets"]:
        print(f"  rejet ligne {r['ligne']} : {r['motif']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
