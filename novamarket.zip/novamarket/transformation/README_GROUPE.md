# S4 — README du groupe

## Reproduire
Tout rejouer depuis la racine : `./run_pipeline.sh` (voir `README.md`). Étapes S4 seules, une fois S1–S3 faits :
```bash
source .venv/bin/activate
export NOVAMARKET_DSN='host=127.0.0.1 port=15432 dbname=novamarket user=atelier' PGPASSWORD=...   # jamais commité
python transformation/chargement_postgres.py     # M1 (rejouable) ; --entree pour un autre lot
python transformation/test_chargement.py         # preuve : échec => aucune écriture partielle
docker compose --profile transfo build dbt       # une fois
mkdir -p s4/travail/profil && cp transformation/dbt/profiles.exemple.yml s4/travail/profil/profiles.yml
export DBT_ENV_SECRET_PASSWORD=... DBT_DATABASE=novamarket
docker compose --profile transfo run --rm --no-deps --user "$(id -u):$(id -g)" -w /projet \
  -e DBT_ENV_SECRET_PASSWORD -e DBT_DATABASE dbt dbt build --profiles-dir /work/profil
```

## M1 — choix
- Schéma `fournisseur`, table `offres`, **clé (offer_id, observed_on)** : une offre peut avoir plusieurs dates.
- Rejeu : `INSERT … ON CONFLICT DO UPDATE … WHERE ligne différente` → 1er passage 20 insérées ; 2e passage 20 inchangées, 0 doublon. Une valeur modifiée est comptée « mise à jour ».
- Contrôles Python avant écriture (types, dates ISO, devise EUR, valeurs ≥ 0, produit au catalogue, doublon dans le lot) → rejets listés avec motif ; contraintes CHECK/FK en base en filet.
- Tout le lot dans une transaction ; `test_chargement.py` : une FK violée à la ligne 2 annule la ligne 1.
- Référentiel produits : `public.products` chargé depuis `s1/donnees/products.csv` (la base n'avait pas les tables S1/S2). Ce CSV contient le produit 3 en double → ignoré (`ON CONFLICT DO NOTHING`).

## dbt (M2–M5)
- `source()` : `fournisseur.offres`, `public.products`.
- staging (views) `stg_offres` (grain inchangé, + `price_eur`), `stg_produits` ; intermediate (ephemeral) `int_offres_enrichies` (jointure N→1, grain préservé) ; mart (table) `mart_offres_par_produit`, grain = produit.
- `dbt build` : PASS=20 (17 tests : unicité du grain, not_null, relationships, accepted_values, + test singulier qui vérifie que le mart conserve toutes les observations).
- Volumes : source 20 → staging 20 → mart 20 observations (20 produits × 1 observation : le mart a 20 lignes parce que le lot de secours contient une offre par produit ; avec plusieurs dates il aura moins de lignes que le staging, c'est attendu).

## Limites
- dbt s'exécute via le service Docker du compose (dbt-core 1.11.17). Le kit S4 est arrivé dans `s4/s4/` et a été fusionné dans `s4/` ; `transformation/` et `ingestion/` (ex-`s3/`) sont à la racine, comme l'attend le compose.
- Le conteneur PostgreSQL avait un montage `/s1` périmé (vide) ; il a été recréé (`docker compose up -d --force-recreate postgres`, données conservées dans le volume).
- Pas de vérification S5 (Java, PySpark, Hugging Face) : non demandée ici.
