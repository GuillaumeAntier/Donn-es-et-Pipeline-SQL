-- Réutilisable : chaque observation d'offre + attributs produit.
-- Jointure many-to-one (offre -> produit, product_id unique) : le grain
-- (offer_id, observed_on) est préservé, aucune multiplication de lignes.
select
    o.offer_id,
    o.observed_on,
    o.supplier_id,
    o.product_id,
    p.sku,
    p.product_name,
    p.category_id,
    o.price_cents,
    o.price_eur,
    o.available_units
from {{ ref('stg_offres') }} as o
inner join {{ ref('stg_produits') }} as p using (product_id)
