-- Grain : un produit.
select
    product_id,
    sku,
    product_name,
    category_id,
    first_listed_on
from {{ source('catalogue', 'products') }}
