-- Grain inchangé : (offer_id, observed_on). Renommage + prix en euros, rien d'autre.
select
    offer_id,
    observed_on,
    supplier_id,
    product_id,
    price_cents,
    price_cents / 100.0 as price_eur,
    currency,
    available_units
from {{ source('fournisseur', 'offres') }}
