-- Grain : un produit ayant au moins une offre. Matérialisé en table (petit volume,
-- lu par la BI en S6) ; les étapes amont restent légères (view / ephemeral).
select
    product_id,
    sku,
    product_name,
    category_id,
    count(*)                         as nb_observations,
    count(distinct supplier_id)      as nb_fournisseurs,
    min(price_eur)                   as prix_min_eur,
    round(avg(price_eur), 2)         as prix_moyen_eur,
    max(price_eur)                   as prix_max_eur,
    sum(available_units)             as unites_disponibles,
    max(observed_on)                 as derniere_observation
from {{ ref('int_offres_enrichies') }}
group by product_id, sku, product_name, category_id
