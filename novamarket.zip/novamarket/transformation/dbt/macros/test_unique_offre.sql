{% test dbt_utils_free_unique_offre(model) %}
-- échoue pour chaque couple (offer_id, observed_on) présent plusieurs fois
select offer_id, observed_on, count(*) as n
from {{ model }}
group by offer_id, observed_on
having count(*) > 1
{% endtest %}
