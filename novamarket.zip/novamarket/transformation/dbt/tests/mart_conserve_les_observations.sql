-- Échoue si le mart perd ou multiplie des observations par rapport au staging.
select s.n_stg, m.n_mart
from (select count(*) as n_stg from {{ ref('stg_offres') }}) s
cross join (select sum(nb_observations) as n_mart from {{ ref('mart_offres_par_produit') }}) m
where s.n_stg <> m.n_mart
