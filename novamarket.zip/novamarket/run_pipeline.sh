#!/usr/bin/env bash
# Rejoue NovaMarket de S1 à S4 sur une base PostgreSQL locale. À lancer depuis novamarket/.
#   ./run_pipeline.sh                      # base "novamarket"
#   NOVAMARKET_DB=ma_base ./run_pipeline.sh
# Les schémas dérivés (fournisseur, dbt_dev) sont recréés ; les tables S1/S2 sont reconstruites par m2 / s2_m1.
set -euo pipefail
cd "$(dirname "$0")"

DB="${NOVAMARKET_DB:-novamarket}"
export PGPASSWORD="${PGPASSWORD:-novamarket_s1_local}"      # mot de passe de démonstration du compose
PY=.venv/bin/python
psql_c() { docker compose exec -T -e PGPASSWORD postgres psql -X -q -v ON_ERROR_STOP=1 -U atelier "$@"; }
etape() { printf '\n\033[1m== %s\033[0m\n' "$*"; }

etape "0. Environnement (PostgreSQL, API fournisseur, venv Python)"
[ -x "$PY" ] || { python3.12 -m venv .venv && .venv/bin/pip install -q -r requirements-v3.txt; }
docker compose up -d --build --wait postgres fournisseur
psql_c -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$DB'" | grep -q 1 \
  || psql_c -d postgres -c "CREATE DATABASE \"$DB\""
psql_c -d "$DB" -c "DROP SCHEMA IF EXISTS fournisseur, dbt_dev CASCADE"

etape "S1. Réception, intégration, indicateurs, anomalies, contrôles"
for f in m2 m3 m4 m5; do psql_c -d "$DB" -f "/s1/$f.sql" > "/tmp/s1_$f.out" || { cat "/tmp/s1_$f.out"; exit 1; }; done
cat /tmp/s1_m5.out

etape "S2. Catalogue et analyses"
docker compose exec -T postgres mkdir -p /tmp/novamarket-s2
docker compose cp s2/donnees/. postgres:/tmp/novamarket-s2/
psql_c -d "$DB" < s2/s2_m1.sql
psql_c -d "$DB" < s2/s2_m2.sql > /dev/null
echo "(s2_m3, benchmark sur 10 M de lignes : non rejoué, il dépend d'un générateur absent du dépôt)"

etape "S3. Collecte asynchrone (scénario atelier, run neuf)"
psql_c -d "$DB" -tAc "SELECT product_id FROM products ORDER BY 1" > ingestion/catalogue_produits.txt
RUN="pipeline-$(date +%Y%m%d-%H%M%S)"
$PY -m unittest discover -s ingestion/tests 2>&1 | tail -3
$PY ingestion/src/collecteur.py --scenario atelier --run "$RUN" --catalogue ingestion/catalogue_produits.txt
$PY ingestion/tests/verifier_sorties.py "$RUN" --attendu 24 20 4

etape "S4. Chargement PostgreSQL (1er passage, rejeu, test d'échec)"
export NOVAMARKET_DSN="host=127.0.0.1 port=${NOVAMARKET_PG_PORT:-15432} dbname=$DB user=atelier"
$PY transformation/chargement_postgres.py
$PY transformation/chargement_postgres.py
$PY transformation/test_chargement.py

etape "S4. dbt (build de l'image, puis compile / run / build)"
mkdir -p s4/travail/profil
[ -f s4/travail/profil/profiles.yml ] || cp transformation/dbt/profiles.exemple.yml s4/travail/profil/profiles.yml
docker compose --profile transfo build dbt
export DBT_ENV_SECRET_PASSWORD="$PGPASSWORD" DBT_DATABASE="$DB"
dbt() { docker compose --profile transfo run --rm --no-deps --user "$(id -u):$(id -g)" -w /projet \
          -e DBT_ENV_SECRET_PASSWORD -e DBT_DATABASE dbt dbt "$@" --profiles-dir /work/profil; }
dbt debug | tail -2; dbt compile | tail -1; dbt run | tail -1; dbt build | tail -1

etape "Volumes source -> staging -> mart"
psql_c -d "$DB" -c "SELECT (SELECT count(*) FROM fournisseur.offres) AS source,
  (SELECT count(*) FROM dbt_dev.stg_offres) AS staging,
  (SELECT sum(nb_observations) FROM dbt_dev.mart_offres_par_produit) AS mart"
