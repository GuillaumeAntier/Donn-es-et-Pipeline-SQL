DROP SCHEMA IF EXISTS reception CASCADE;
DROP TABLE IF EXISTS rejets, payments, order_items, orders, customers;

-- 1. Tables de réception (text, sans contrainte)
CREATE SCHEMA reception;
CREATE TABLE reception.customers   (customer_id text, customer_name text, city text);
CREATE TABLE reception.orders      (order_id text, customer_id text, ordered_on text, status text);
CREATE TABLE reception.order_items (order_item_id text, order_id text, product_id text, quantity text, unit_price_cents text);
CREATE TABLE reception.payments    (document jsonb);

-- 2. Tables métier
CREATE TABLE customers (
    customer_id   integer PRIMARY KEY,
    customer_name text NOT NULL,
    city          text NOT NULL
);
CREATE TABLE orders (
    order_id    integer PRIMARY KEY,
    customer_id integer NOT NULL REFERENCES customers,
    ordered_on  date NOT NULL,
    status      text NOT NULL CHECK (status IN ('completed', 'pending', 'cancelled'))
);
CREATE TABLE order_items (
    order_item_id    integer PRIMARY KEY,
    order_id         integer NOT NULL REFERENCES orders,
    product_id       integer NOT NULL,
    quantity         integer NOT NULL CHECK (quantity > 0),
    unit_price_cents integer NOT NULL CHECK (unit_price_cents >= 0)
);
CREATE TABLE payments (
    payment_id   integer PRIMARY KEY,
    order_id     integer NOT NULL REFERENCES orders,
    paid_on      date NOT NULL,
    amount_cents integer NOT NULL CHECK (amount_cents > 0),
    status       text NOT NULL CHECK (status IN ('captured', 'pending'))
);

-- 3. Journal des rejets
CREATE TABLE rejets (
    source  text,
    cle     text,
    motif   text,
    contenu text
);

-- 4. Import brut
\copy reception.customers   FROM '/s1/donnees/customers.csv'   WITH (FORMAT csv, HEADER true)
\copy reception.orders      FROM '/s1/donnees/orders.csv'      WITH (FORMAT csv, HEADER true)
\copy reception.order_items FROM '/s1/donnees/order_items.csv' WITH (FORMAT csv, HEADER true)
\copy reception.payments    FROM '/s1/donnees/payments.ndjson' WITH (FORMAT csv, QUOTE E'\x01', DELIMITER E'\x02')

-- 5. Intégration (ordre : customers -> orders -> order_items / payments)
INSERT INTO customers
SELECT DISTINCT customer_id::int, customer_name, city FROM reception.customers;

INSERT INTO orders
SELECT DISTINCT order_id::int, customer_id::int, ordered_on::date, status FROM reception.orders;

-- order_items : rejet des doublons et des commandes inexistantes
INSERT INTO rejets
SELECT 'order_items.csv', order_item_id, 'doublon', concat_ws(',', order_item_id, order_id, product_id, quantity, unit_price_cents)
FROM (SELECT *, row_number() OVER (PARTITION BY order_item_id) AS n FROM reception.order_items) r
WHERE n > 1;

INSERT INTO rejets
SELECT 'order_items.csv', order_item_id, 'commande inexistante', concat_ws(',', order_item_id, order_id, product_id, quantity, unit_price_cents)
FROM reception.order_items
WHERE order_id::int NOT IN (SELECT order_id FROM orders);

INSERT INTO order_items
SELECT DISTINCT order_item_id::int, order_id::int, product_id::int, quantity::int, unit_price_cents::int
FROM reception.order_items
WHERE order_id::int IN (SELECT order_id FROM orders);

-- payments : lecture du NDJSON
INSERT INTO rejets
SELECT 'payments.ndjson', document->>'payment_id', 'commande inexistante', document::text
FROM reception.payments
WHERE (document->>'order_id')::int NOT IN (SELECT order_id FROM orders);

INSERT INTO payments
SELECT DISTINCT (document->>'payment_id')::int, (document->>'order_id')::int,
       (document->>'paid_on')::date, (document->>'amount_cents')::int, document->>'status'
FROM reception.payments
WHERE (document->>'order_id')::int IN (SELECT order_id FROM orders);

-- 6. Comptages : brut / intégré / rejeté
SELECT 'customers' AS source, (SELECT count(*) FROM reception.customers) AS brut, (SELECT count(*) FROM customers) AS integre, (SELECT count(*) FROM rejets WHERE source = 'customers.csv') AS rejete
UNION ALL SELECT 'orders',      (SELECT count(*) FROM reception.orders),      (SELECT count(*) FROM orders),      (SELECT count(*) FROM rejets WHERE source = 'orders.csv')
UNION ALL SELECT 'order_items', (SELECT count(*) FROM reception.order_items), (SELECT count(*) FROM order_items), (SELECT count(*) FROM rejets WHERE source = 'order_items.csv')
UNION ALL SELECT 'payments',    (SELECT count(*) FROM reception.payments),    (SELECT count(*) FROM payments),    (SELECT count(*) FROM rejets WHERE source = 'payments.ndjson');

-- 7. Journal des rejets
SELECT * FROM rejets;
