-- M3 : indicateurs commerciaux (à lancer après s1/m2.sql)
-- Lancer : docker compose exec -T postgres psql -U atelier -d novamarket < s1/m3.sql

-- 1. Commandes par statut
SELECT status, count(*) AS commandes
FROM orders
GROUP BY status;

-- 1. Clients sans commande
SELECT count(*) AS clients_sans_commande
FROM customers c
WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.customer_id = c.customer_id);

-- 2. Montant des lignes des commandes terminées et panier moyen
--    Dénominateur = nombre de commandes terminées (pas le nombre de lignes)
SELECT count(DISTINCT o.order_id)                                              AS commandes_terminees,
       round(sum(i.quantity * i.unit_price_cents) / 100.0, 2)                  AS montant_eur,
       round(sum(i.quantity * i.unit_price_cents) / 100.0 / count(DISTINCT o.order_id), 2) AS panier_moyen_eur
FROM orders o
JOIN order_items i ON i.order_id = o.order_id
WHERE o.status = 'completed';

-- 3. Rapprochement lignes / paiements : on additionne chaque table par commande AVANT de joindre
WITH lignes AS (
    SELECT order_id, sum(quantity * unit_price_cents) AS montant FROM order_items GROUP BY order_id
), paiements AS (
    SELECT order_id, sum(amount_cents) AS montant FROM payments GROUP BY order_id
)
SELECT o.status,
       round(sum(l.montant) / 100.0, 2) AS lignes_eur,
       round(sum(p.montant) / 100.0, 2) AS paiements_eur
FROM orders o
JOIN lignes    l ON l.order_id = o.order_id
JOIN paiements p ON p.order_id = o.order_id
GROUP BY o.status;
