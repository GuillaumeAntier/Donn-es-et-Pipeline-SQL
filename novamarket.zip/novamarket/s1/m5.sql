-- M5 : contrôles essentiels (à lancer après s1/m2.sql)
-- Lancer : docker compose exec -T postgres psql -U atelier -d novamarket < s1/m5.sql

SELECT 'brut = intégré + rejeté' AS controle,
       CASE WHEN (SELECT count(*) FROM reception.order_items)
               = (SELECT count(*) FROM order_items) + (SELECT count(*) FROM rejets WHERE source = 'order_items.csv')
            THEN 'OK' ELSE 'KO' END AS resultat
UNION ALL
SELECT 'aucun article sans commande',
       CASE WHEN NOT EXISTS (SELECT 1 FROM order_items i WHERE i.order_id NOT IN (SELECT order_id FROM orders))
            THEN 'OK' ELSE 'KO' END
UNION ALL
SELECT 'aucun paiement sans commande',
       CASE WHEN NOT EXISTS (SELECT 1 FROM payments p WHERE p.order_id NOT IN (SELECT order_id FROM orders))
            THEN 'OK' ELSE 'KO' END
UNION ALL
SELECT 'total lignes = total paiements',
       CASE WHEN (SELECT sum(quantity * unit_price_cents) FROM order_items) = (SELECT sum(amount_cents) FROM payments)
            THEN 'OK' ELSE 'KO' END;
