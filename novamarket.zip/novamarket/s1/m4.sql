-- M4 : anomalies (à lancer après s1/m2.sql)
-- Lancer : docker compose exec -T postgres psql -U atelier -d novamarket < s1/m4.sql

-- 1. Doublons de lignes dans le fichier brut
SELECT order_item_id, count(*) AS nb
FROM reception.order_items
GROUP BY order_item_id
HAVING count(*) > 1;

-- 1. Références de commande orphelines (commande inexistante)
SELECT order_item_id, order_id
FROM reception.order_items
WHERE order_id NOT IN (SELECT order_id FROM reception.orders);

-- 2. Multiplication des montants : jointure directe articles + paiements
SELECT round(sum(i.quantity * i.unit_price_cents) / 100.0, 2) AS montant_faux_eur
FROM orders o
JOIN order_items i ON i.order_id = o.order_id
JOIN payments    p ON p.order_id = o.order_id
WHERE o.status = 'completed';

-- 2. Montant correct (sans les paiements)
SELECT round(sum(i.quantity * i.unit_price_cents) / 100.0, 2) AS montant_correct_eur
FROM orders o
JOIN order_items i ON i.order_id = o.order_id
WHERE o.status = 'completed';

-- 3. Impact du statut de commande sur le CA
SELECT o.status, round(sum(i.quantity * i.unit_price_cents) / 100.0, 2) AS montant_eur
FROM orders o
JOIN order_items i ON i.order_id = o.order_id
GROUP BY o.status;
