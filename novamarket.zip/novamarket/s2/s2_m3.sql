-- S2 M3 : benchmark avant / après index (à lancer après s3/generer.sql)
-- Lancer : docker compose exec -T postgres psql -U atelier -d novamarket < s2/s2_m3.sql > s2/s2_m3_resultats.txt
-- Filtre 1 : store_id = 42 -> très sélectif (environ 100 lignes sur 10 millions)
-- Filtre 2 : store_id = 1  -> peu sélectif (95 % des lignes)
-- Chaque requête est mesurée 3 fois : le 1er passage est à part, on garde la médiane des 3.

\timing on
DROP INDEX IF EXISTS benchmark.benchmark_sales_store_idx;

-- 0. Volume
SELECT count(*) AS lignes FROM benchmark.benchmark_sales;
SELECT store_id = 1 AS magasin_1, count(*) FROM benchmark.benchmark_sales GROUP BY 1;

-- 1. AVANT index
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 42;
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 42;
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 42;

EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 1;
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 1;
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 1;

-- 2. Création de l'index (temps affiché par \timing) et taille
CREATE INDEX benchmark_sales_store_idx ON benchmark.benchmark_sales (store_id);
ANALYZE benchmark.benchmark_sales;
SELECT pg_size_pretty(pg_relation_size('benchmark.benchmark_sales_store_idx')) AS taille_index,
       pg_size_pretty(pg_relation_size('benchmark.benchmark_sales'))           AS taille_table;

-- 3. APRÈS index
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 42;
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 42;
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 42;

EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 1;
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 1;
EXPLAIN (ANALYZE, BUFFERS) SELECT count(*), sum(amount_cents) FROM benchmark.benchmark_sales WHERE store_id = 1;
