-- S2 M2 : analyses avancées (à lancer après s1/m2.sql et s2/s2_m1.sql)
-- Lancer : docker compose exec -T postgres psql -U atelier -d novamarket < s2/s2_m2.sql
-- Périmètre : lignes des commandes terminées (completed), montants en euros.

-- 1. Classement des produits par CA, dans chaque catégorie, avec RANK()
--    CTE ca_produit : grain de sortie = 1 ligne par produit
WITH ca_produit AS (
    SELECT p.category_id, p.product_id, round(sum(i.quantity * i.unit_price_cents) / 100.0, 2) AS ca_eur
    FROM order_items i
    JOIN orders o   ON o.order_id = i.order_id
    JOIN products p ON p.product_id = i.product_id
    WHERE o.status = 'completed'
    GROUP BY p.category_id, p.product_id
)
SELECT category_id, product_id, ca_eur,
       rank() OVER (PARTITION BY category_id ORDER BY ca_eur DESC) AS rang
FROM ca_produit
ORDER BY category_id, rang;

-- 2. Évolution mensuelle du CA avec LAG()
--    CTE ca_mois : grain de sortie = 1 ligne par mois
WITH ca_mois AS (
    SELECT date_trunc('month', o.ordered_on)::date AS mois,
           min(o.ordered_on) AS premier_jour,
           max(o.ordered_on) AS dernier_jour,
           round(sum(i.quantity * i.unit_price_cents) / 100.0, 2) AS ca_eur
    FROM orders o
    JOIN order_items i ON i.order_id = o.order_id
    WHERE o.status = 'completed'
    GROUP BY 1
)
SELECT mois, premier_jour, dernier_jour, ca_eur,
       lag(ca_eur) OVER (ORDER BY mois) AS ca_mois_precedent,
       round(100 * (ca_eur - lag(ca_eur) OVER (ORDER BY mois)) / lag(ca_eur) OVER (ORDER BY mois), 1) AS evolution_pct,
       CASE WHEN dernier_jour < (date_trunc('month', mois) + interval '1 month - 1 day')::date
            THEN 'incomplet' ELSE 'complet' END AS periode
FROM ca_mois
ORDER BY mois;
