-- S2 M1 : intégration du catalogue (à lancer après s1/m2.sql)
-- Avant : copier les fichiers dans le conteneur
--   docker compose exec -T postgres mkdir -p /tmp/novamarket-s2
--   docker compose cp s2/donnees/. postgres:/tmp/novamarket-s2/
-- Lancer : docker compose exec -T postgres psql -U atelier -d novamarket < s2/s2_m1.sql

ALTER TABLE order_items DROP CONSTRAINT IF EXISTS order_items_product_fk;
DROP TABLE IF EXISTS reception.categories, reception.products, products, categories;
DELETE FROM rejets WHERE source IN ('categories.csv', 'products.csv');

-- 1. Tables de réception (text, sans contrainte)
CREATE TABLE reception.categories (category_id text, category_name text, parent_category_id text);
CREATE TABLE reception.products   (product_id text, sku text, product_name text, category_id text, first_listed_on text);

-- 2. Tables métier
CREATE TABLE categories (
    category_id        integer PRIMARY KEY,
    category_name      text NOT NULL,
    parent_category_id integer REFERENCES categories   -- NULL = catégorie racine
);
CREATE TABLE products (
    product_id      integer PRIMARY KEY,
    sku             text NOT NULL UNIQUE,
    product_name    text NOT NULL,
    category_id     integer NOT NULL REFERENCES categories,
    first_listed_on date NOT NULL
);

-- 3. Import brut
\copy reception.categories FROM '/tmp/novamarket-s2/categories.csv' WITH (FORMAT csv, HEADER true)
\copy reception.products   FROM '/tmp/novamarket-s2/products.csv'   WITH (FORMAT csv, HEADER true)

-- 4. Intégration (catégories avant produits)
INSERT INTO categories
SELECT DISTINCT category_id::int, category_name, parent_category_id::int FROM reception.categories;

INSERT INTO rejets
SELECT 'products.csv', product_id, 'doublon', concat_ws(',', product_id, sku, product_name, category_id, first_listed_on)
FROM (SELECT *, row_number() OVER (PARTITION BY product_id) AS n FROM reception.products) r
WHERE n > 1;

INSERT INTO products
SELECT DISTINCT product_id::int, sku, product_name, category_id::int, first_listed_on::date FROM reception.products;

-- 5. Lien ventes -> catalogue (possible car tous les produits vendus existent)
ALTER TABLE order_items ADD CONSTRAINT order_items_product_fk FOREIGN KEY (product_id) REFERENCES products;

-- 6. Comptages : brut / intégré / rejeté
SELECT 'categories' AS source, (SELECT count(*) FROM reception.categories) AS brut, (SELECT count(*) FROM categories) AS integre, (SELECT count(*) FROM rejets WHERE source = 'categories.csv') AS rejete
UNION ALL SELECT 'products', (SELECT count(*) FROM reception.products), (SELECT count(*) FROM products), (SELECT count(*) FROM rejets WHERE source = 'products.csv');

-- 7. Rapprochement produits / lignes de commandes
SELECT 'produits vendus absents du catalogue' AS controle, count(DISTINCT product_id) AS nb
FROM order_items WHERE product_id NOT IN (SELECT product_id FROM products)
UNION ALL
SELECT 'produits du catalogue jamais vendus', count(*)
FROM products WHERE product_id NOT IN (SELECT product_id FROM order_items)
UNION ALL
SELECT 'catégories parentes inexistantes', count(*)
FROM reception.categories WHERE parent_category_id IS NOT NULL AND parent_category_id NOT IN (SELECT category_id FROM reception.categories);

-- 8. Écarts à expliquer
-- a) Effet du doublon si on joignait les ventes au catalogue brut
SELECT count(*) AS lignes_produit_3_avec_doublon
FROM order_items i JOIN reception.products p ON p.product_id::int = i.product_id
WHERE i.product_id = 3;

-- b) Ventes avant la date de première mise en vente
SELECT p.product_id, p.first_listed_on, count(*) AS lignes_vendues_avant
FROM order_items i
JOIN orders o   ON o.order_id = i.order_id
JOIN products p ON p.product_id = i.product_id
WHERE o.ordered_on < p.first_listed_on
GROUP BY p.product_id, p.first_listed_on;

-- 9. Journal des rejets du catalogue
SELECT * FROM rejets WHERE source IN ('categories.csv', 'products.csv');
