# NovaMarket — pipeline de données S1 → S4

Marketplace fictive : des fichiers bruts deviennent une base PostgreSQL propre, des offres fournisseurs collectées par API, puis un modèle analytique dbt.

| Séance | Dossier | Contenu |
| --- | --- | --- |
| S1 | `s1/` | réception en texte, tables typées, rejets tracés, indicateurs, anomalies, contrôles (`m2`–`m5.sql`) |
| S2 | `s2/` | catalogue (catégories, produits), analyses avancées, benchmark d'index |
| S3 | `ingestion/` (alias `s3/`) | collecteur asynchrone de l'API fournisseur (retries, concurrence bornée), sorties `raw/valid/rejected`, bilans |
| S4 | `transformation/`, `s4/` | chargeur PostgreSQL rejouable + projet dbt (staging → intermediate → mart) |

## Tout rejouer
```bash
./run_pipeline.sh                           # base "novamarket"
NOVAMARKET_DB=autre_base ./run_pipeline.sh  # autre base (créée si absente)
```
Prérequis : Docker + Compose, Python 3.12. Le script démarre PostgreSQL et l'API, rejoue S1 à S4 et affiche les contrôles (S3 « CONFORME », rejeu à 0 insertion, `dbt build` 20/20, volumes source = staging = mart). Mot de passe local par défaut : celui du compose, surchargeable via `PGPASSWORD`.

## Documentation par séance
`s1/DEMARRAGE.md` · `s2/README.md` · `ingestion/MODE_EMPLOI.md` et `ingestion/CONTRAT.md` · `transformation/README_GROUPE.md` (choix et preuves S4).

## Limite connue
Le benchmark S2 (`s2/s2_m3.sql`, 10 M de lignes) n'est pas rejoué : il attend un générateur (`generer.sql`) absent du dépôt.
