"""Tests unitaires des règles de validation (sans API ni réseau).

    python -m unittest discover -s ingestion/tests -v
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from validation import (CHAMPS_CONTRAT, charger_catalogue,  # noqa: E402
                        controler_structure_et_metier, valider_pages)

CATALOGUE = range(1, 25)


def offre(**modifs):
    base = dict(offer_id="O001", supplier_id="F01", product_id=1, price_cents=625,
                currency="EUR", available_units=2, observed_on="2026-11-24")
    base.update(modifs)
    return base


class TestControles(unittest.TestCase):
    def motifs(self, item):
        return controler_structure_et_metier(item, CATALOGUE)

    def test_offre_conforme(self):
        self.assertEqual(self.motifs(offre()), [])

    def test_champ_manquant(self):
        item = offre()
        del item["supplier_id"]
        self.assertEqual(self.motifs(item), ["champ_manquant:supplier_id"])

    def test_champ_nul_equivaut_a_manquant(self):
        self.assertEqual(self.motifs(offre(currency=None)), ["champ_manquant:currency"])

    def test_prix_texte(self):
        self.assertEqual(self.motifs(offre(price_cents="inconnu")), ["type_invalide:price_cents"])

    def test_prix_flottant_refuse(self):
        self.assertEqual(self.motifs(offre(price_cents=6.25)), ["type_invalide:price_cents"])

    def test_booleen_nest_pas_un_entier(self):
        self.assertEqual(self.motifs(offre(available_units=True)), ["type_invalide:available_units"])

    def test_valeur_negative(self):
        self.assertEqual(self.motifs(offre(available_units=-1)), ["valeur_negative:available_units"])

    def test_produit_inconnu(self):
        self.assertEqual(self.motifs(offre(product_id=9999)), ["produit_inconnu"])

    def test_devise(self):
        self.assertEqual(self.motifs(offre(currency="USD")), ["devise_invalide"])

    def test_dates(self):
        for mauvaise in ("2026-02-30", "24/11/2026", "2026-11-24T10:00:00", 20261124):
            with self.subTest(date=mauvaise):
                self.assertEqual(self.motifs(offre(observed_on=mauvaise)), ["date_invalide"])

    def test_fournisseur(self):
        self.assertEqual(self.motifs(offre(supplier_id="")), ["identifiant_invalide:supplier_id"])
        self.assertEqual(self.motifs(offre(supplier_id="ACME")), ["identifiant_invalide:supplier_id"])

    def test_item_non_objet(self):
        self.assertEqual(self.motifs(["pas", "un", "objet"]), ["item_non_objet"])


class TestLot(unittest.TestCase):
    def test_doublon_conserve_la_premiere_occurrence(self):
        pages = {6: [offre(offer_id="O001", product_id=2)], 1: [offre()]}  # désordre volontaire
        d = valider_pages(pages, CATALOGUE)
        self.assertEqual([(x.page, x.valide) for x in d], [(1, True), (6, False)])
        self.assertEqual(d[1].motifs, ["doublon_offer_id"])

    def test_champs_supplementaires_non_publies(self):
        d = valider_pages({1: [offre(commentaire="interne")]}, CATALOGUE)
        self.assertEqual(tuple(d[0].offre), CHAMPS_CONTRAT)

    def test_rejet_trace_page_position_objet(self):
        brut = offre(product_id=9999)
        r = valider_pages({5: [brut]}, CATALOGUE)[0].rejet()
        self.assertEqual((r["page"], r["position"], r["motif"], r["objet_brut"]),
                         (5, 1, "produit_inconnu", brut))


class TestCatalogue(unittest.TestCase):
    def test_fichier_avec_entete_et_commentaires(self):
        import tempfile
        with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, encoding="utf-8") as f:
            f.write("product_id,nom\n1,Lampe\n# commentaire\n2,Table\n")
        self.assertEqual(charger_catalogue(f.name), {1, 2})

    def test_plage_par_defaut(self):
        cat = charger_catalogue(None)
        self.assertIn(24, cat)
        self.assertNotIn(9999, cat)


if __name__ == "__main__":
    unittest.main()
