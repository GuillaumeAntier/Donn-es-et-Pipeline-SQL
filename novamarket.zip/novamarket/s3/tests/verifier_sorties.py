"""Contrôle indépendant des sorties d'un run (preuve d'exécution, M4).

    python ingestion/tests/verifier_sorties.py <run> [--attendu 24 20 4]

Relit les fichiers produits sans réutiliser le code du collecteur et vérifie :
UTF-8 + un objet JSON par ligne, champs du contrat seuls dans valid/,
offer_id uniques, rejets motivés avec page et position, et cohérence avec le bilan.
"""
import argparse
import json
import sys
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "data"
CHAMPS = {"offer_id", "supplier_id", "product_id", "price_cents", "currency",
          "available_units", "observed_on"}


def lire_jsonl(chemin: Path) -> list:
    lignes = chemin.read_bytes().decode("utf-8").splitlines()  # échoue si pas UTF-8
    return [json.loads(l) for l in lignes if l.strip()]


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("run")
    p.add_argument("--attendu", nargs=3, type=int, metavar=("LIGNES", "VALIDES", "REJETS"))
    p.add_argument("--data", default=str(DATA))
    a = p.parse_args()
    data = Path(a.data)
    erreurs = []

    def verifier(condition, message):
        print(("  OK   " if condition else "  ÉCHEC ") + message)
        if not condition:
            erreurs.append(message)

    bilan = json.loads((data / "bilans" / f"{a.run}.json").read_text(encoding="utf-8"))
    rejets = lire_jsonl(data / "rejected" / f"{a.run}.jsonl")
    raw = lire_jsonl(data / "raw" / f"{a.run}.jsonl")
    print(f"Run {a.run} — statut {bilan['statut']}")

    verifier(len(raw) == bilan["requetes_http"] - bilan["erreurs_par_type"].get("timeout", 0),
             f"raw : {len(raw)} réponses reçues (requêtes - timeouts)")
    verifier(all({"page", "position", "motif", "objet_brut"} <= r.keys() for r in rejets),
             f"rejected : {len(rejets)} rejets avec page, position, motif, objet_brut")
    verifier(len(rejets) == bilan["lignes_rejetees"], "rejected cohérent avec le bilan")
    verifier(bilan["lignes_examinees"] == bilan["lignes_valides"] + bilan["lignes_rejetees"],
             "examinées = valides + rejetées")
    verifier(bilan["requetes_simultanees_max_observees"] <= bilan["concurrence_max"],
             f"concurrence bornée (pic {bilan['requetes_simultanees_max_observees']} "
             f"≤ {bilan['concurrence_max']})")

    lot = data / "valid" / "lots" / f"{a.run}.jsonl"
    if bilan["statut"] == "SUCCES":
        valides = lire_jsonl(lot)
        verifier(len(valides) == bilan["lignes_valides"], f"valid : {len(valides)} offres")
        verifier(all(set(v) == CHAMPS for v in valides), "valid : uniquement les champs du contrat")
        ids = [v["offer_id"] for v in valides]
        verifier(len(ids) == len(set(ids)), "valid : offer_id uniques")
        verifier(bilan["pages_recues"] == bilan["pages_attendues"], "toutes les pages reçues")
        if a.attendu:
            verifier([bilan["lignes_examinees"], bilan["lignes_valides"], bilan["lignes_rejetees"]]
                     == a.attendu, f"volumes attendus {a.attendu}")
    else:
        verifier(not lot.exists(), "lot en échec : aucun fichier valide publié pour ce run")

    print("Résultat :", "CONFORME" if not erreurs else f"{len(erreurs)} contrôle(s) en échec")
    return 0 if not erreurs else 1


if __name__ == "__main__":
    sys.exit(main())
