"""Compare collecte séquentielle et concurrente bornée (M2), même scénario, runs neufs.

    python ingestion/tests/comparer_modes.py [--scenario clean] [--concurrence 3]

Les sorties vont dans un dossier temporaire : data/ n'est pas modifié.
"""
import argparse
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

COLLECTEUR = Path(__file__).resolve().parents[1] / "src" / "collecteur.py"


def lancer(scenario, mode, concurrence, sortie):
    run = f"cmp-{mode}-{time.strftime('%H%M%S')}-{int(time.time() * 1000) % 1000}"
    subprocess.run([sys.executable, str(COLLECTEUR), "--scenario", scenario, "--run", run,
                    "--mode", mode, "--concurrence", str(concurrence), "--sortie", sortie],
                   check=False, capture_output=True)
    return json.loads((Path(sortie) / "bilans" / f"{run}.json").read_text(encoding="utf-8"))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--scenario", default="clean", choices=["clean", "atelier"])
    p.add_argument("--concurrence", type=int, default=3)
    a = p.parse_args()
    with tempfile.TemporaryDirectory() as sortie:
        lignes = [("séquentiel", lancer(a.scenario, "sequentiel", 1, sortie)),
                  (f"concurrent ({a.concurrence})", lancer(a.scenario, "concurrent", a.concurrence, sortie)),
                  ("concurrent (6)", lancer(a.scenario, "concurrent", 6, sortie))]
    print(f"Scénario {a.scenario}")
    print(f"{'mode':<18}{'durée s':>9}{'requêtes':>10}{'pic':>5}{'valides':>9}{'rejets':>8}  statut")
    for nom, b in lignes:
        print(f"{nom:<18}{b['duree_s']:>9}{b['requetes_http']:>10}"
              f"{b['requetes_simultanees_max_observees']:>5}{b['lignes_valides']:>9}"
              f"{b['lignes_rejetees']:>8}  {b['statut']}")


if __name__ == "__main__":
    main()
