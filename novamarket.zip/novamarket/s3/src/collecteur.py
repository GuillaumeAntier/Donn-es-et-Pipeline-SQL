"""Collecteur asynchrone des offres fournisseurs NovaMarket (missions M2 à M4).

Usage (depuis la racine novamarket/, venv activé) :

    python ingestion/src/collecteur.py --scenario atelier --run groupe01-essai01

Déroulé :
1. lit la page 1 pour connaître ``total_pages`` ;
2. lit les pages 2..N en concurrence BORNÉE (sémaphore + pool aiohttp) ;
3. chaque requête a un timeout ; les erreurs transitoires (timeout, 429, 5xx,
   JSON invalide) sont réessayées un nombre borné de fois, en respectant
   ``Retry-After`` ou, à défaut, un backoff exponentiel avec aléa ;
4. vérifie la complétude de la pagination ; si une page manque, le lot est
   déclaré en ÉCHEC et rien n'est publié dans ``valid/`` ;
5. valide chaque offre (validation.py) et écrit raw / valid / rejected,
   le journal JSONL et le bilan.

Codes de sortie : 0 succès, 2 lot incomplet (rien de publié), 1 erreur d'usage.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import random
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import aiohttp

from journalisation import Bilan, configurer_journal, fermer_journal
from validation import charger_catalogue, valider_pages

RACINE_INGESTION = Path(__file__).resolve().parents[1]
STATUTS_TRANSITOIRES = {429, 500, 502, 503, 504}
RE_RUN = re.compile(r"[a-zA-Z0-9_-]{1,64}")


class ErreurTransitoire(Exception):
    """Incident qui peut disparaître si l'on réessaie (réseau, quota, 5xx…)."""

    def __init__(self, type_erreur: str, attente_serveur: float | None = None):
        super().__init__(type_erreur)
        self.type_erreur = type_erreur
        self.attente_serveur = attente_serveur


class ErreurPermanente(Exception):
    """Incident qu'un nouvel essai identique ne corrigera pas (400, 404…)."""


class PageEnEchec(Exception):
    def __init__(self, page: int, cause: str):
        super().__init__(f"page {page} : {cause}")
        self.page = page
        self.cause = cause


def lire_retry_after(valeur: str | None) -> float | None:
    """Retry-After en secondes (la forme date HTTP n'est pas utilisée par l'API)."""
    if valeur is None:
        return None
    try:
        return max(0.0, float(valeur))
    except ValueError:
        return None


class Collecteur:
    def __init__(self, base_url: str, scenario: str, run: str, *, concurrence: int,
                 tentatives: int, timeout_s: float, backoff_s: float, attente_max_s: float,
                 logger, bilan: Bilan):
        self.base_url = base_url.rstrip("/")
        self.scenario = scenario
        self.run = run
        self.tentatives = tentatives
        self.timeout = aiohttp.ClientTimeout(total=timeout_s)
        self.backoff_s = backoff_s
        self.attente_max_s = attente_max_s
        self.log = logger
        self.bilan = bilan
        self.limite = asyncio.Semaphore(concurrence)
        self.concurrence = concurrence
        self.en_vol = 0
        self.reponses_brutes: list[dict] = []

    # ---------- une requête HTTP (un essai) ----------
    async def _un_essai(self, session: aiohttp.ClientSession, page: int, tentative: int) -> dict:
        params = {"page": str(page), "scenario": self.scenario, "run": self.run}
        async with self.limite:  # au plus N requêtes simultanées
            self.en_vol += 1
            self.bilan.requetes_simultanees_max_observees = max(
                self.bilan.requetes_simultanees_max_observees, self.en_vol)
            self.bilan.requetes_http += 1
            debut = time.perf_counter()
            try:
                async with session.get(f"{self.base_url}/offers", params=params) as rep:
                    corps = await rep.read()
                    statut = rep.status
                    retry_after = lire_retry_after(rep.headers.get("Retry-After"))
            except (TimeoutError, asyncio.TimeoutError):
                raise ErreurTransitoire("timeout") from None
            except aiohttp.ClientError as exc:
                raise ErreurTransitoire(f"connexion:{type(exc).__name__}") from None
            finally:
                self.en_vol -= 1
        duree_ms = round((time.perf_counter() - debut) * 1000)

        texte = corps.decode("utf-8", errors="replace")
        try:
            donnees = json.loads(texte)
            json_ok = True
        except json.JSONDecodeError:
            donnees, json_ok = None, False

        # raw : on garde TOUT ce qui a été reçu, avant toute décision.
        self.reponses_brutes.append({
            "page": page, "tentative": tentative, "statut_http": statut,
            "recu_le": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "duree_ms": duree_ms, "json_valide": json_ok,
            "corps": donnees if json_ok else texte,
        })

        if statut in STATUTS_TRANSITOIRES:
            raise ErreurTransitoire(f"http_{statut}", retry_after)
        if statut != 200:
            raise ErreurPermanente(f"http_{statut}")
        if not json_ok:
            raise ErreurTransitoire("json_invalide")
        self._controler_enveloppe(donnees, page)
        self.log.info("page_recue", extra={"page": page, "tentative": tentative,
                                           "statut": statut, "items": len(donnees["items"]),
                                           "duree_ms": duree_ms})
        return donnees

    @staticmethod
    def _controler_enveloppe(d, page: int) -> None:
        """Contrat de transport : la page reçue est bien celle demandée et lisible."""
        ok = (isinstance(d, dict) and d.get("page") == page
              and isinstance(d.get("total_pages"), int) and d["total_pages"] >= 1
              and isinstance(d.get("items"), list) and "next_page" in d)
        if not ok:
            raise ErreurTransitoire("enveloppe_invalide")

    # ---------- une page, avec reprises bornées ----------
    async def lire_page(self, session: aiohttp.ClientSession, page: int) -> dict:
        for tentative in range(1, self.tentatives + 1):
            try:
                return await self._un_essai(session, page, tentative)
            except ErreurPermanente as exc:
                self.bilan.erreurs_par_type[str(exc)] += 1
                self.log.error("erreur_permanente", extra={"page": page, "tentative": tentative,
                                                          "erreur": str(exc)})
                raise PageEnEchec(page, str(exc)) from None
            except ErreurTransitoire as exc:
                self.bilan.erreurs_par_type[exc.type_erreur] += 1
                if tentative == self.tentatives:
                    self.log.error("page_abandonnee", extra={
                        "page": page, "tentative": tentative, "erreur": exc.type_erreur})
                    raise PageEnEchec(page, f"{exc.type_erreur} après {tentative} essais") from None
                if exc.attente_serveur is not None:
                    attente = min(exc.attente_serveur, self.attente_max_s)
                    self.bilan.attente_retry_after_s += attente
                    origine = "retry_after"
                else:
                    attente = min(self.backoff_s * 2 ** (tentative - 1), self.attente_max_s)
                    attente += random.uniform(0, self.backoff_s / 2)  # aléa : évite les rafales
                    origine = "backoff"
                self.bilan.reprises += 1
                self.log.warning("essai_echoue", extra={
                    "page": page, "tentative": tentative, "erreur": exc.type_erreur,
                    "attente_s": round(attente, 3), "origine_attente": origine})
                # On attend HORS du sémaphore : la place est libérée pour une autre page.
                await asyncio.sleep(attente)
        raise AssertionError("inatteignable")

    # ---------- toutes les pages ----------
    async def collecter(self, mode: str) -> tuple[dict[int, list], list[PageEnEchec]]:
        connecteur = aiohttp.TCPConnector(limit=self.concurrence)
        async with aiohttp.ClientSession(timeout=self.timeout, connector=connecteur) as session:
            try:
                premiere = await self.lire_page(session, 1)
            except PageEnEchec as exc:
                return {}, [exc]
            total = premiere["total_pages"]
            self.bilan.pages_attendues = total
            recues = {1: premiere}
            echecs: list[PageEnEchec] = []
            suivantes = range(2, total + 1)

            if mode == "sequentiel":
                for p in suivantes:
                    try:
                        recues[p] = await self.lire_page(session, p)
                    except PageEnEchec as exc:
                        echecs.append(exc)
            else:
                resultats = await asyncio.gather(
                    *(self.lire_page(session, p) for p in suivantes), return_exceptions=True)
                for p, r in zip(suivantes, resultats):
                    if isinstance(r, PageEnEchec):
                        echecs.append(r)
                    elif isinstance(r, BaseException):
                        raise r  # bogue inattendu : on ne le masque pas
                    else:
                        recues[p] = r

        echecs += self._controler_pagination(recues, total)
        return {p: d["items"] for p, d in recues.items()}, echecs

    @staticmethod
    def _controler_pagination(recues: dict[int, dict], total: int) -> list[PageEnEchec]:
        """Complétude : total_pages identique partout, chaîne next_page cohérente."""
        problemes = []
        for p, d in sorted(recues.items()):
            attendu = p + 1 if p < total else None
            if d["total_pages"] != total:
                problemes.append(PageEnEchec(p, "total_pages incoherent"))
            elif d["next_page"] != attendu:
                problemes.append(PageEnEchec(p, f"next_page={d['next_page']} attendu {attendu}"))
        return problemes


# ---------------- écriture des sorties ----------------
def relatif(chemin: Path) -> str:
    """Chemin affiché depuis la racine novamarket/ (portable d'une machine à l'autre)."""
    try:
        return Path(chemin).resolve().relative_to(RACINE_INGESTION.parent).as_posix()
    except ValueError:
        return str(chemin)


def ecrire_jsonl(chemin: Path, lignes) -> int:
    chemin.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with chemin.open("w", encoding="utf-8", newline="\n") as f:
        for ligne in lignes:
            f.write(json.dumps(ligne, ensure_ascii=False) + "\n")
            n += 1
    return n


def publier(valides: list[dict], dossier_valid: Path, run: str) -> Path:
    """Publication atomique : l'ancien offres.jsonl est archivé, puis remplacé
    d'un seul coup (os.replace). Un lecteur ne voit jamais un fichier à moitié écrit."""
    cible = dossier_valid / "offres.jsonl"
    archives = dossier_valid / "archives"
    temporaire = dossier_valid / f".offres.{run}.tmp"
    ecrire_jsonl(temporaire, valides)
    if cible.exists():
        archives.mkdir(parents=True, exist_ok=True)
        horodatage = datetime.now().strftime("%Y%m%dT%H%M%S")
        os.replace(cible, archives / f"offres_{horodatage}_avant_{run}.jsonl")
    os.replace(temporaire, cible)
    return cible


def analyser_arguments(argv=None):
    port = os.environ.get("NOVAMARKET_API_PORT", "18080")
    p = argparse.ArgumentParser(description="Collecte asynchrone des offres fournisseurs NovaMarket.")
    p.add_argument("--scenario", choices=["clean", "atelier", "panne"], default="atelier")
    p.add_argument("--run", help="identifiant d'essai (lettres, chiffres, - et _). Défaut : horodaté.")
    p.add_argument("--mode", choices=["concurrent", "sequentiel"], default="concurrent")
    p.add_argument("--concurrence", type=int, default=3, help="requêtes simultanées max (défaut 3)")
    p.add_argument("--tentatives", type=int, default=4, help="essais max par page (défaut 4)")
    p.add_argument("--timeout", type=float, default=1.0, help="timeout d'une requête en s (défaut 1.0)")
    p.add_argument("--backoff", type=float, default=0.2, help="délai de base du backoff en s")
    p.add_argument("--attente-max", type=float, default=5.0, help="plafond d'une attente entre essais (s)")
    p.add_argument("--catalogue", help="fichier des product_id connus (un par ligne), export du catalogue S2")
    p.add_argument("--base-url", default=f"http://127.0.0.1:{port}")
    p.add_argument("--sortie", default=str(RACINE_INGESTION / "data"), help="dossier data/")
    p.add_argument("--ecraser", action="store_true", help="autorise la réutilisation d'un run existant")
    a = p.parse_args(argv)
    if a.mode == "sequentiel":
        a.concurrence = 1
    if a.run is None:
        a.run = f"{a.scenario}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    if not RE_RUN.fullmatch(a.run):
        p.error("--run : 1 à 64 caractères parmi lettres, chiffres, - et _")
    if a.concurrence < 1 or a.tentatives < 1 or a.timeout <= 0:
        p.error("--concurrence, --tentatives et --timeout doivent être positifs")
    return a


async def executer(a) -> int:
    data = Path(a.sortie)
    chemins = {
        "raw": data / "raw" / f"{a.run}.jsonl",
        "rejected": data / "rejected" / f"{a.run}.jsonl",
        "lot_valide": data / "valid" / "lots" / f"{a.run}.jsonl",
        "journal": data / "logs" / f"{a.run}.log.jsonl",
        "bilan": data / "bilans" / f"{a.run}.json",
    }
    if chemins["raw"].exists() and not a.ecraser:
        print(f"Le run {a.run!r} existe déjà ({chemins['raw']}). Choisissez un run neuf "
              "ou ajoutez --ecraser.", file=sys.stderr)
        return 1

    catalogue = charger_catalogue(a.catalogue)
    log = configurer_journal(chemins["journal"])
    bilan = Bilan(run=a.run, scenario=a.scenario, mode=a.mode,
                  concurrence_max=a.concurrence, tentatives_max=a.tentatives)
    log.info("collecte_demarree", extra={"run": a.run, "scenario": a.scenario, "mode": a.mode,
                                          "concurrence": a.concurrence, "tentatives": a.tentatives,
                                          "timeout_s": a.timeout, "base_url": a.base_url})
    collecteur = Collecteur(a.base_url, a.scenario, a.run, concurrence=a.concurrence,
                            tentatives=a.tentatives, timeout_s=a.timeout, backoff_s=a.backoff,
                            attente_max_s=a.attente_max, logger=log, bilan=bilan)
    try:
        pages, echecs = await collecteur.collecter(a.mode)

        # Validation dans l'ordre (page, position), indépendamment de l'ordre d'arrivée.
        decisions = valider_pages(pages, catalogue)
        valides = [d.offre for d in decisions if d.valide]
        rejets = [d.rejet() for d in decisions if not d.valide]
        for r in rejets:
            log.warning("offre_rejetee", extra={"page": r["page"], "position": r["position"],
                                                "motif": r["motif"]})
            bilan.motifs_rejet[r["motif"]] += 1
        bilan.pages_recues = len(pages)
        bilan.pages_en_echec = sorted({e.page for e in echecs})
        bilan.lignes_examinees = len(decisions)
        bilan.lignes_valides = len(valides)
        bilan.lignes_rejetees = len(rejets)

        ecrire_jsonl(chemins["raw"], collecteur.reponses_brutes)
        ecrire_jsonl(chemins["rejected"], rejets)
        bilan.fichiers = {k: relatif(v) for k, v in chemins.items() if k in ("raw", "rejected", "journal", "bilan")}

        incoherences = bilan.verifier_coherence()
        if echecs or incoherences:
            bilan.statut = "ECHEC"
            bilan.publication = "aucune : lot incomplet, valid/offres.jsonl inchangé"
            for e in echecs:
                log.error("lot_incomplet", extra={"page": e.page, "cause": e.cause})
            for i in incoherences:
                log.error("bilan_incoherent", extra={"controle": i})
        else:
            ecrire_jsonl(chemins["lot_valide"], valides)
            cible = publier(valides, data / "valid", a.run)
            bilan.statut = "SUCCES"
            bilan.publication = relatif(cible)
            bilan.fichiers["lot_valide"] = relatif(chemins["lot_valide"])
            bilan.fichiers["valid"] = relatif(cible)
    finally:
        bilan.terminer()
        log.info("collecte_terminee", extra={"statut": bilan.statut, "duree_s": bilan.duree_s,
                                             "requetes_http": bilan.requetes_http})
        bilan.ecrire(chemins["bilan"])
        fermer_journal()
    print(bilan.resume())
    return 0 if bilan.statut == "SUCCES" else 2


def main(argv=None) -> int:
    return asyncio.run(executer(analyser_arguments(argv)))


if __name__ == "__main__":
    sys.exit(main())
