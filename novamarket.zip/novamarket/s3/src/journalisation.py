"""Journal d'exécution et bilan de collecte (missions M3 et M4).

- Le journal est double : lisible dans la console, structuré (JSONL) dans un
  fichier. Chaque événement a un nom stable (``page_recue``, ``essai_echoue``…)
  et des champs ``extra`` (page, tentative, statut…).
- Le bilan agrège les compteurs de fin d'exécution. Il distingue les essais
  HTTP (requêtes) des lignes (offres) : ce ne sont pas les mêmes grandeurs.
"""
from __future__ import annotations

import json
import logging
import time
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

NOM_LOGGER = "novamarket.ingestion"
# Attributs standard d'un LogRecord : tout le reste vient de ``extra``.
_ATTRIBUTS_STANDARD = set(vars(logging.makeLogRecord({}))) | {"message", "asctime", "taskName"}


def _champs_extra(record: logging.LogRecord) -> dict:
    return {k: v for k, v in vars(record).items() if k not in _ATTRIBUTS_STANDARD}


class FormatJSON(logging.Formatter):
    """Une ligne JSON par événement, horodatée en UTC."""

    def format(self, record):
        ligne = {
            "horodatage": datetime.fromtimestamp(record.created, timezone.utc).isoformat(timespec="milliseconds"),
            "niveau": record.levelname,
            "evenement": record.getMessage(),
            **_champs_extra(record),
        }
        return json.dumps(ligne, ensure_ascii=False, default=str)


class FormatConsole(logging.Formatter):
    """``12:00:01.234 INFO  page_recue page=2 tentative=2 statut=200``."""

    def format(self, record):
        heure = datetime.fromtimestamp(record.created).strftime("%H:%M:%S.%f")[:-3]
        extras = " ".join(f"{k}={v}" for k, v in _champs_extra(record).items())
        return f"{heure} {record.levelname:<7} {record.getMessage()} {extras}".rstrip()


def configurer_journal(fichier: Path | None, niveau: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(NOM_LOGGER)
    logger.setLevel(niveau)
    logger.handlers.clear()
    logger.propagate = False
    console = logging.StreamHandler()
    console.setFormatter(FormatConsole())
    logger.addHandler(console)
    if fichier is not None:
        fichier.parent.mkdir(parents=True, exist_ok=True)
        f = logging.FileHandler(fichier, mode="w", encoding="utf-8")
        f.setFormatter(FormatJSON())
        logger.addHandler(f)
    return logger


def fermer_journal() -> None:
    logger = logging.getLogger(NOM_LOGGER)
    for h in list(logger.handlers):
        h.close()
        logger.removeHandler(h)


@dataclass
class Bilan:
    run: str
    scenario: str
    mode: str
    concurrence_max: int
    tentatives_max: int
    debut: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="seconds"))
    statut: str = "EN_COURS"  # SUCCES | ECHEC
    pages_attendues: int | None = None
    pages_recues: int = 0
    pages_en_echec: list[int] = field(default_factory=list)
    requetes_http: int = 0
    reprises: int = 0
    erreurs_par_type: Counter = field(default_factory=Counter)
    attente_retry_after_s: float = 0.0
    requetes_simultanees_max_observees: int = 0
    lignes_examinees: int = 0
    lignes_valides: int = 0
    lignes_rejetees: int = 0
    motifs_rejet: Counter = field(default_factory=Counter)
    duree_s: float | None = None
    publication: str | None = None
    fichiers: dict = field(default_factory=dict)
    _t0: float = field(default_factory=time.perf_counter, repr=False)

    def terminer(self) -> None:
        self.duree_s = round(time.perf_counter() - self._t0, 3)

    def verifier_coherence(self) -> list[str]:
        """Invariants qui doivent tenir pour qu'un lot soit publiable."""
        problemes = []
        if self.lignes_examinees != self.lignes_valides + self.lignes_rejetees:
            problemes.append("lignes_examinees != valides + rejetees")
        if self.pages_attendues is None or self.pages_recues != self.pages_attendues:
            problemes.append("pages_recues != pages_attendues")
        if self.requetes_http < self.pages_recues:
            problemes.append("requetes_http < pages_recues")
        if self.requetes_simultanees_max_observees > self.concurrence_max:
            problemes.append("concurrence depassee")
        return problemes

    def en_dict(self) -> dict:
        d = asdict(self)
        d.pop("_t0", None)
        d["erreurs_par_type"] = dict(self.erreurs_par_type)
        d["motifs_rejet"] = dict(self.motifs_rejet)
        return d

    def ecrire(self, chemin: Path) -> None:
        chemin.parent.mkdir(parents=True, exist_ok=True)
        chemin.write_text(json.dumps(self.en_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def resume(self) -> str:
        erreurs = ", ".join(f"{k}={v}" for k, v in sorted(self.erreurs_par_type.items())) or "aucune"
        motifs = ", ".join(f"{k}={v}" for k, v in sorted(self.motifs_rejet.items())) or "aucun"
        return "\n".join([
            "=" * 64,
            f"BILAN  run={self.run}  scénario={self.scenario}  mode={self.mode}",
            "=" * 64,
            f"Statut                 : {self.statut}",
            f"Pages reçues/attendues : {self.pages_recues}/{self.pages_attendues}"
            + (f"  (échec : {self.pages_en_echec})" if self.pages_en_echec else ""),
            f"Requêtes HTTP          : {self.requetes_http}  dont reprises : {self.reprises}",
            f"Erreurs HTTP / réseau  : {erreurs}",
            f"Concurrence            : limite={self.concurrence_max}  pic observé={self.requetes_simultanees_max_observees}",
            f"Lignes examinées       : {self.lignes_examinees}",
            f"  valides              : {self.lignes_valides}",
            f"  rejetées             : {self.lignes_rejetees}  ({motifs})",
            f"Durée                  : {self.duree_s} s",
            f"Publication            : {self.publication}",
            "=" * 64,
        ])
