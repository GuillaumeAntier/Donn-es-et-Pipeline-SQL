"""Contrôles des offres fournisseurs et motifs de rejet (mission M4).

Deux niveaux de contrôle, dans cet ordre :
1. structure : champs requis, types, format de date ;
2. métier    : valeurs non négatives, devise, produit connu du catalogue,
               unicité de la clé métier ``offer_id``.

Chaque offre reçoit une décision : acceptée (objet limité aux champs du
contrat) ou rejetée (liste de motifs). Une offre n'est jamais « corrigée »
silencieusement.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

# Champs du contrat, dans l'ordre d'écriture des fichiers valides.
CHAMPS_CONTRAT = (
    "offer_id",
    "supplier_id",
    "product_id",
    "price_cents",
    "currency",
    "available_units",
    "observed_on",
)

MOTIF_ITEM_NON_OBJET = "item_non_objet"
MOTIF_CHAMP_MANQUANT = "champ_manquant"
MOTIF_TYPE_INVALIDE = "type_invalide"
MOTIF_VALEUR_NEGATIVE = "valeur_negative"
MOTIF_DEVISE_INVALIDE = "devise_invalide"
MOTIF_DATE_INVALIDE = "date_invalide"
MOTIF_IDENTIFIANT_INVALIDE = "identifiant_invalide"
MOTIF_PRODUIT_INCONNU = "produit_inconnu"
MOTIF_DOUBLON = "doublon_offer_id"

RE_FOURNISSEUR = re.compile(r"F\d{2}")
RE_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")

# Hypothèse documentée : sans export du catalogue S2, on accepte les
# identifiants produits de 1 à 1000. Fournir --catalogue pour la vraie liste.
PLAGE_PRODUITS_DEFAUT = range(1, 1001)


def charger_catalogue(chemin: str | Path | None) -> set[int] | range:
    """Lit un fichier d'identifiants produits (un entier par ligne, ``#`` = commentaire).

    Sans fichier, renvoie la plage par défaut. Une première ligne non numérique
    (en-tête CSV ``product_id``) est ignorée ; seule la première colonne compte.
    """
    if chemin is None:
        return PLAGE_PRODUITS_DEFAUT
    ids: set[int] = set()
    for numero, ligne in enumerate(Path(chemin).read_text(encoding="utf-8").splitlines(), 1):
        valeur = ligne.split("#", 1)[0].split(",", 1)[0].strip()
        if not valeur:
            continue
        try:
            ids.add(int(valeur))
        except ValueError:
            if numero == 1:
                continue  # en-tête
            raise ValueError(f"{chemin}:{numero}: identifiant produit non entier : {valeur!r}")
    if not ids:
        raise ValueError(f"{chemin} : catalogue vide")
    return ids


def _est_entier(valeur) -> bool:
    # bool est une sous-classe de int en Python : True ne doit pas passer pour 1.
    return isinstance(valeur, int) and not isinstance(valeur, bool)


@dataclass
class Decision:
    page: int
    position: int
    brut: object
    motifs: list[str] = field(default_factory=list)
    offre: dict | None = None

    @property
    def valide(self) -> bool:
        return not self.motifs

    def rejet(self) -> dict:
        return {
            "page": self.page,
            "position": self.position,
            "motif": self.motifs[0],
            "motifs": self.motifs,
            "objet_brut": self.brut,
        }


def controler_structure_et_metier(item: object, catalogue) -> list[str]:
    """Renvoie la liste des motifs de rejet (vide si l'offre est conforme)."""
    if not isinstance(item, dict):
        return [MOTIF_ITEM_NON_OBJET]

    motifs: list[str] = []
    manquants = [c for c in CHAMPS_CONTRAT if c not in item or item[c] is None]
    motifs += [f"{MOTIF_CHAMP_MANQUANT}:{c}" for c in manquants]

    def present(champ):
        return champ not in manquants

    # Identifiants texte stables.
    for champ in ("offer_id", "supplier_id"):
        if present(champ):
            v = item[champ]
            if not isinstance(v, str):
                motifs.append(f"{MOTIF_TYPE_INVALIDE}:{champ}")
            elif not v.strip():
                motifs.append(f"{MOTIF_IDENTIFIANT_INVALIDE}:{champ}")
    if present("supplier_id") and isinstance(item["supplier_id"], str) and item["supplier_id"].strip():
        if not RE_FOURNISSEUR.fullmatch(item["supplier_id"]):
            motifs.append(f"{MOTIF_IDENTIFIANT_INVALIDE}:supplier_id")

    # Entiers non négatifs.
    for champ in ("product_id", "price_cents", "available_units"):
        if present(champ):
            v = item[champ]
            if not _est_entier(v):
                motifs.append(f"{MOTIF_TYPE_INVALIDE}:{champ}")
            elif v < 0:
                motifs.append(f"{MOTIF_VALEUR_NEGATIVE}:{champ}")

    if present("currency") and item["currency"] != "EUR":
        motifs.append(MOTIF_DEVISE_INVALIDE)

    if present("observed_on"):
        v = item["observed_on"]
        try:
            if not (isinstance(v, str) and RE_DATE.fullmatch(v)):
                raise ValueError
            date.fromisoformat(v)
        except ValueError:
            motifs.append(MOTIF_DATE_INVALIDE)

    # Règle métier : le produit doit exister au catalogue (seulement si le type est bon).
    if present("product_id") and _est_entier(item["product_id"]) and item["product_id"] >= 0:
        if item["product_id"] not in catalogue:
            motifs.append(MOTIF_PRODUIT_INCONNU)
    return motifs


def valider_pages(pages: dict[int, list], catalogue) -> list[Decision]:
    """Valide toutes les offres dans l'ordre (page, position).

    L'ordre est fixé AVANT la validation : même si les pages sont arrivées dans
    le désordre (collecte concurrente), le résultat est déterministe. Le premier
    ``offer_id`` rencontré est conservé, les suivants sont des doublons.
    """
    decisions: list[Decision] = []
    deja_vus: dict[str, tuple[int, int]] = {}
    for page in sorted(pages):
        for position, item in enumerate(pages[page], start=1):
            d = Decision(page=page, position=position, brut=item)
            d.motifs = controler_structure_et_metier(item, catalogue)
            if not d.motifs:
                cle = item["offer_id"]
                if cle in deja_vus:
                    d.motifs.append(MOTIF_DOUBLON)
                else:
                    deja_vus[cle] = (page, position)
                    d.offre = {c: item[c] for c in CHAMPS_CONTRAT}
            decisions.append(d)
    return decisions
