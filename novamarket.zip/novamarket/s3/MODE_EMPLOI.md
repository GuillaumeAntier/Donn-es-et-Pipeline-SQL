# Mode d'emploi du collecteur (S3)

Toutes les commandes se lancent **depuis la racine `novamarket/`** (le dossier qui contient `compose.yaml`).

## 1. Installation (une seule fois)

```bash
python3.12 -m venv .venv
source .venv/bin/activate            # Windows PowerShell : .venv\Scripts\Activate.ps1
python -m pip install -r requirements-v3.txt
```

## 2. Démarrer l'API fournisseur

```bash
docker compose up -d --build --wait fournisseur
python ingestion/tests/disponibilite.py          # doit afficher : API disponible
curl -fsS 'http://127.0.0.1:18080/offers?page=1&scenario=clean&run=sonde01'
```

## 3. Lancer une collecte

```bash
# référence sans incident
python ingestion/src/collecteur.py --scenario clean   --run groupe01-clean-01
# essai principal (429, JSON invalide, timeout, 4 offres non conformes)
python ingestion/src/collecteur.py --scenario atelier --run groupe01-atelier-01
# panne permanente : le lot doit être refusé (code de sortie 2)
python ingestion/src/collecteur.py --scenario panne   --run groupe01-panne-01; echo "code=$?"
# comparaison : collecte séquentielle
python ingestion/src/collecteur.py --scenario atelier --run groupe01-atelier-seq --mode sequentiel
```

Règle : **un `run` neuf à chaque essai** (sinon le serveur ne rejoue pas ses erreurs et le collecteur refuse d'écraser les fichiers ; `--ecraser` force la réutilisation).

Options :

| Option | Défaut | Effet |
| --- | --- | --- |
| `--scenario` | `atelier` | `clean`, `atelier` ou `panne` |
| `--run` | horodaté | identifiant de l'essai |
| `--mode` | `concurrent` | `sequentiel` force la concurrence à 1 |
| `--concurrence` | 3 | requêtes HTTP simultanées au maximum |
| `--tentatives` | 4 | essais au maximum par page |
| `--timeout` | 1.0 | délai max d'une requête (s) |
| `--backoff` | 0.2 | délai de base du backoff exponentiel (s) |
| `--attente-max` | 5.0 | plafond d'une attente entre deux essais (s) |
| `--catalogue` | plage 1–1000 | fichier des `product_id` connus (catalogue S2) |
| `--base-url` | `http://127.0.0.1:$NOVAMARKET_API_PORT` | adresse de l'API |
| `--sortie` | `ingestion/data` | dossier des sorties |

Codes de sortie : `0` lot publié, `2` lot incomplet (rien publié), `1` erreur d'usage.

## 4. Vérifier

```bash
python -m unittest discover -s ingestion/tests -v                          # 17 tests de validation
python ingestion/tests/verifier_sorties.py groupe01-atelier-01 --attendu 24 20 4
python ingestion/tests/verifier_sorties.py groupe01-panne-01
python ingestion/tests/comparer_modes.py --scenario clean                   # séquentiel vs concurrent
python ingestion/tests/comparer_modes.py --scenario atelier
```

## 5. Sorties produites

```
ingestion/data/
├── raw/<run>.jsonl            toutes les réponses HTTP reçues (page, tentative, statut, corps)
├── rejected/<run>.jsonl       page, position, motif, objet_brut
├── valid/offres.jsonl         lot publié (champs du contrat) → entrée de S4
├── valid/lots/<run>.jsonl     copie du lot de chaque run réussi
├── valid/archives/            anciennes versions de offres.jsonl
├── logs/<run>.log.jsonl       journal structuré, un événement par ligne
└── bilans/<run>.json          compteurs : pages, requêtes, reprises, lignes, durée, statut
```

## 6. Catalogue produits (règle `produit_inconnu`)

Sans `--catalogue`, les `product_id` de 1 à 1000 sont acceptés (hypothèse documentée). Pour utiliser le vrai catalogue S2 :

```bash
docker compose up -d --wait postgres
# adapter le nom de la table produits de votre schéma S2
docker compose exec -T postgres psql -U atelier -d novamarket -At \
  -c "SELECT product_id FROM produits ORDER BY 1" > ingestion/catalogue_produits.txt
python ingestion/src/collecteur.py --scenario atelier --run groupe01-atelier-02 \
  --catalogue ingestion/catalogue_produits.txt
```

## 7. Dépannage

| Symptôme | Action |
| --- | --- |
| `API disponible` ne s'affiche pas | `docker compose ps`, `docker compose logs fournisseur` |
| Port 18080 pris | `export NOVAMARKET_API_PORT=18081` puis relancer Compose **et** le collecteur dans ce même shell |
| `ModuleNotFoundError: aiohttp` | venv non activé : `source .venv/bin/activate` puis `pip install -r requirements-v3.txt` |
| `Le run ... existe déjà` | choisir un nouveau `--run` |
| Pas d'erreur 429 en atelier | le `run` a déjà été utilisé côté serveur : en prendre un neuf |
| S3 non terminé | S4 peut partir de `transformation/secours/offres.jsonl` |

## 8. Dépôt

Ne pas versionner `.venv/`, les volumes Docker ni les gros fichiers générés (voir `.gitignore`). Déposer le code, ce mode d'emploi, `CONTRAT.md` et le bilan du run de référence.
