# Contrat de l'API fournisseur NovaMarket (M1)

Observé le 24/11/2026 sur l'API locale `http://127.0.0.1:18080` (service Compose `fournisseur`).

## 1. Endpoints

| Méthode | Route | Rôle | Réponse |
| --- | --- | --- | --- |
| GET | `/health` | sonde de disponibilité | `{"status":"ok"}` |
| GET | `/offers?page=N&scenario=S&run=R` | une page d'offres | enveloppe ci-dessous |
| GET | `/demo` | exemple technique (cuves), hors projet | `{"unite":"litre","valeur":42}` |

Paramètres de `/offers` :

| Paramètre | Valeurs | Si invalide |
| --- | --- | --- |
| `page` | entier de 1 à 6 | 400 `{"error":"page"}` ou `{"error":"parametres"}` |
| `scenario` | `clean`, `atelier`, `panne` | 400 |
| `run` | 1 à 64 car. `[a-zA-Z0-9_-]` | 400 |

Le serveur compte les essais par couple (scénario, run, page). Les fautes de `atelier` ne surviennent qu'au **premier** essai d'une page : il faut un `run` neuf pour les rejouer.

## 2. Enveloppe et pagination

```json
{"page": 1, "total_pages": 6, "next_page": 2, "items": [ ...4 offres... ]}
```

- Pagination **par numéro**, 6 pages × 4 offres = 24 lignes.
- `next_page` vaut `page + 1`, puis `null` sur la dernière page.
- **Condition d'arrêt** : on lit `total_pages` sur la page 1, puis on demande les pages 2 à `total_pages`. On contrôle ensuite que `total_pages` est identique partout et que la chaîne `next_page` est continue jusqu'à `null`. Toute page manquante rend le lot incomplet.

## 3. Une offre

| Champ | Type | Règle |
| --- | --- | --- |
| `offer_id` | texte non vide | **clé métier**, unique dans un lot |
| `supplier_id` | texte `F` + 2 chiffres | F01, F02, F03 en simulation |
| `product_id` | entier | doit exister au catalogue S2 |
| `price_cents` | entier ≥ 0 | prix en centimes |
| `currency` | texte | vaut `EUR` |
| `available_units` | entier ≥ 0 | unités disponibles |
| `observed_on` | texte `AAAA-MM-JJ` | date ISO réelle |

Exemple de réponse (scénario `clean`, données fictives) :

```json
{"offer_id": "O001", "supplier_id": "F01", "product_id": 1, "price_cents": 625,
 "currency": "EUR", "available_units": 2, "observed_on": "2026-11-24"}
```

## 4. Comparaison des scénarios

Un HTTP 200 ne garantit pas une donnée correcte : la page 3 du scénario `atelier` répond 200 avec un corps qui n'est pas du JSON.

| Page | `clean` | `atelier` (1er essai) | `atelier` (anomalies de données) | `panne` |
| --- | --- | --- | --- | --- |
| 1 | 200 | 200 | — | 200 |
| 2 | 200 | **429** + `Retry-After: 1` | offre 1 sans `supplier_id` | 200 |
| 3 | 200 | **200 + JSON invalide** | offre 2 : `price_cents = "inconnu"` | 200 |
| 4 | 200 | **réponse après ≈1,5 s** (timeout côté client) | — | 200 |
| 5 | 200 | 200 | offre 1 : `product_id = 9999` | 200 |
| 6 | 200 | 200 | offre 4 = copie de `O001` (doublon) | **503 permanent** |

Résultat attendu sur `atelier` : 24 lignes examinées, 20 valides, 4 rejetées.

## 5. Classement des incidents

| Incident | Classe | Action |
| --- | --- | --- |
| timeout, erreur de connexion | transitoire | réessai avec backoff |
| 429 | transitoire | réessai après `Retry-After` |
| 500, 502, 503, 504 | transitoire | réessai avec backoff, puis abandon de la page |
| 200 + JSON invalide ou enveloppe incohérente | transitoire | réessai (borné) |
| 400, 404, autre 4xx | permanente | pas de réessai, page en échec |
| offre non conforme | donnée | pas de réessai : rejet motivé dans `rejected/` |
